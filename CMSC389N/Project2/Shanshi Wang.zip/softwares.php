<?php
/**
 * Created by PhpStorm.
 * User: swang
 * Date: 16/02/2017
 * Time: 3:00 PM
 */
$softwares = array("AntiVirus" => 20.0, "Firewall" => 15.0, "Registry Cleaner" => 30.0,
                    "AntiSpyware" => 25.0, "WindowsJr7" => 95.0, "MacKitty" => 77.0);